package com.exlservice.plugins;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationConstraint.ValidationType;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.appiancorp.suiteapi.common.Name;
import com.appiancorp.suiteapi.common.exceptions.InvalidVersionException;
import com.appiancorp.suiteapi.common.exceptions.PrivilegeException;
import com.appiancorp.suiteapi.common.exceptions.StorageLimitException;
import com.appiancorp.suiteapi.content.ContentConstants;
import com.appiancorp.suiteapi.content.ContentService;
import com.appiancorp.suiteapi.content.exceptions.DuplicateUuidException;
import com.appiancorp.suiteapi.content.exceptions.InsufficientNameUniquenessException;
import com.appiancorp.suiteapi.content.exceptions.InvalidContentException;
import com.appiancorp.suiteapi.knowledge.Document;
import com.appiancorp.suiteapi.knowledge.DocumentDataType;
import com.appiancorp.suiteapi.knowledge.FolderDataType;
import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.AppianSmartService;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.MessageContainer;
import com.appiancorp.suiteapi.process.framework.Order;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.palette.DocumentManagement;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@DocumentManagement
@PaletteInfo(paletteCategory = "Appian Smart Services", palette = "Document Generation")
@Order({ "Json", "InputExcelTemplate", "SheetNumber", "RowNumber", "HeaderFlag", "SaveInFolder",
		"OutputExcelDocumentName", "SheetName" })
public class JsonToExcelSmartService extends AppianSmartService {

	private static final Logger LOG = Logger.getLogger(JsonToExcelSmartService.class);

	private ContentService cs;
	private String outputExcelDocumentName;
	private Integer sheetNumber;
	private Integer rowNumber;
	private String jsonObject;
	private Long excelTemplate;
	private Long saveInFolder;
	private Long newExcelDocumentCreated;
	private boolean errorOccured;
	private String errorMessage;
	private Boolean headerFlag;
	private String sheetName;

	public JsonToExcelSmartService(ContentService cs) {
		super();
		this.cs = cs;
	}

	@Override
	public void validate(MessageContainer msg) {
		if (outputExcelDocumentName.trim().isEmpty()) {
			msg.addError("NewExcelDocumentName", "documentName.invalidvalue");
		}
		if (sheetNumber < 0) {
			msg.addError("SheetNumber", "sheetNumber.invalidvalue");
		}
		if (rowNumber < 0) {
			msg.addError("RowNumber", "rowNumber.invalidvalue");
		}
	}

	@Override
	public void onSave(MessageContainer msg) {

	}

	@Override
	public void run() throws SmartServiceException {

		File tempExcelFile = null;
		Document excelDocument = new Document();
		try {
			String jsonString = jsonObject;
			if (jsonString.isEmpty()) {
				throw new IllegalArgumentException("Json File IS Empty");
			}
			if (null != excelTemplate) {
				JsonArray json = (JsonArray) new JsonParser().parse(jsonString);
				excelDocument = cs.download(excelTemplate, ContentConstants.VERSION_CURRENT, false)[0];
				tempExcelFile = File.createTempFile(outputExcelDocumentName, ".xlxs");
				withTemplate(tempExcelFile, excelDocument, json);
			} else {
				JsonArray json = (JsonArray) new JsonParser().parse(jsonString);
				tempExcelFile = File.createTempFile(outputExcelDocumentName, ".xlxs");
				withOutTemplate(tempExcelFile, json);
			}
			Long outputDocumentId;
			Document outputExcelDoc = new Document();
			outputExcelDoc.setName(outputExcelDocumentName.trim());
			outputExcelDoc.setExtension("xlsx");
			outputExcelDoc.setParent(saveInFolder);
			outputExcelDoc.setDescription("json to excel");
			outputExcelDoc.setSize((int) tempExcelFile.length());
			outputDocumentId = cs.create(outputExcelDoc, ContentConstants.UNIQUE_NONE);
			Path movedPath = Files.move(tempExcelFile.toPath(), Paths.get(cs.getInternalFilename(outputDocumentId)),
					StandardCopyOption.REPLACE_EXISTING);
			System.out.println("Document Created : " + outputDocumentId);

			if (movedPath == null) {
				throw new IOException("File not Moved");
			}
			LOG.info("Temp File Contents Moved ");
			System.out.println("Temp File Contents Moved ");

			newExcelDocumentCreated = cs.getVersion(outputDocumentId, ContentConstants.VERSION_CURRENT).getId();
			System.out.println("newExcelDocumentCreated : " + newExcelDocumentCreated);
			LOG.info("New Document Created " + newExcelDocumentCreated);
		}

		catch (IOException | StorageLimitException | InsufficientNameUniquenessException | DuplicateUuidException e) {
			errorOccured = true;
			errorMessage = "PLUGIN ERROR :" + e;
		} catch (PrivilegeException | InvalidContentException | InvalidVersionException | RuntimeException e) {
			errorOccured = true;
			errorMessage = "Invalid Document " + e;
		} finally {
			if (tempExcelFile != null)
				try {
					tempExcelFile.delete();
				} catch (Exception e) {
					errorOccured = true;
					errorMessage = "Invalid Document " + e;
				}
		}

	}

	private void withOutTemplate(File tempExcelFile, JsonArray json) throws IOException, FileNotFoundException {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = null;
		Row row = null;
		System.out.println("Before Start Without Template : " + Timestamp.from(Instant.now()));
		int rowNum = rowNumber;
		int colNum = 0;
		addedSheets(workbook);
		// Create headers
		System.out.println("After Sheet Created ");
		sheet = workbook.getSheetAt(sheetNumber);
		if (headerFlag) {
			row = sheet.createRow(rowNum++);
			for (Map.Entry<String, JsonElement> entry : json.get(0).getAsJsonObject().entrySet()) {
				Cell cell = row.createCell(colNum++);
				cell.setCellValue(entry.getKey());
			}
		}
		// Add data
		for (JsonElement jsonElement : json) {
			JsonObject obj = jsonElement.getAsJsonObject();
			row = sheet.createRow(rowNum++);
			colNum = 0;
			for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
				Cell cell = row.createCell(colNum++);
				if (entry.getValue() != null && !(entry.getValue() instanceof JsonNull)) {
					cell.setCellValue(entry.getValue().getAsString());
				}
			}
		}
		System.out.println("After Conversion Without Template :" + Timestamp.from(Instant.now()));
		try (FileOutputStream fos = new FileOutputStream(tempExcelFile)) {
			workbook.write(fos);
			workbook.close();
		}
	}

	private void withTemplate(File tempExcelFile, Document excelDocument, JsonArray json) {
		Workbook tempWorkbook = null;
		Workbook cloneWorkBook = null;
		DataValidation templateValidation = null;
		DataValidationConstraint templateConstraint = null;
		CellRangeAddressList addressList = null;
		DataValidationConstraint clonedConstraint = null;
		DataValidation clonedValidation = null;
		boolean sheetFlag = false;
		Row row = null;
		try {
			tempWorkbook = WorkbookFactory.create(new FileInputStream(excelDocument.getInternalFilename()));
			cloneWorkBook = WorkbookFactory.create(new FileInputStream(excelDocument.getInternalFilename()));
		} catch (EncryptedDocumentException | IOException e1) {
			e1.printStackTrace();
		}
		int rowNum = rowNumber;
		int colNumber = 0;
		System.out.println("Before Start with Template : " + Timestamp.from(Instant.now()));
		sheetFlag = addedSheetsForTemplate(tempWorkbook, cloneWorkBook);
		System.out.println(" sheetFlag : " + sheetFlag);
		Sheet sheetSample = cloneWorkBook.getSheetAt(sheetNumber);
		System.out.println("SheetNumber : sheetSample  " + sheetNumber);
		Sheet sheet = tempWorkbook.getSheetAt(sheetNumber);

		DataValidationHelper validationHelper = sheetSample.getDataValidationHelper();
		int numDataValidations = sheetSample.getDataValidations().size();
		System.out.println("sheetSample.getDataValidations().size()  " + numDataValidations);
		for (int i = 0; i < numDataValidations; i++) {
			templateValidation = sheetSample.getDataValidations().get(i);
			templateConstraint = templateValidation.getValidationConstraint();
			addressList = templateValidation.getRegions();
			DataValidation validation = validationHelper.createValidation(templateConstraint, addressList);
			clonedConstraint = validationHelper.createCustomConstraint(templateConstraint.getFormula1());
			clonedConstraint.setFormula2(templateConstraint.getFormula2());
			clonedConstraint.setOperator(templateConstraint.getOperator());
			clonedValidation = validationHelper.createValidation(clonedConstraint, addressList);
			clonedValidation.setSuppressDropDownArrow(true);
			sheetSample.addValidationData(validation);
		}

		if (headerFlag) {
			System.out.println("headerFlag : " + headerFlag);
			rowNum = writingHeadersInExcel(tempWorkbook, sheet, json, rowNum, colNumber, sheetSample, sheetFlag);
		}

		FormulaEvaluator evaluator = tempWorkbook.getCreationHelper().createFormulaEvaluator();
		for (JsonElement jsonElement : json) {
			rowNum = writingDataToExcel(tempWorkbook, sheet, rowNum, sheetSample, evaluator, jsonElement);
			System.out.println("rowNum : +  " + rowNum);
		}
		System.out.println("After Conversion with Template : " + Timestamp.from(Instant.now()));

		try (FileOutputStream fileOut = new FileOutputStream(tempExcelFile)) {
			ZipSecureFile.setMinInflateRatio(0.0);
			XSSFFormulaEvaluator.evaluateAllFormulaCells(tempWorkbook);
			tempWorkbook.write(fileOut);
			System.out.println("fos :  " + fileOut.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Data written successfully!");
	}

	private void addedSheets(Workbook workbook) {
		for (int i = 0; i <= sheetNumber; i++) {
			if (i == sheetNumber) {
				workbook.createSheet(sheetName);
			} else {
				workbook.createSheet();
			}
		}
		System.out.println("Sheet Created ");

	}

	private boolean addedSheetsForTemplate(Workbook tempWorkbook, Workbook cloneWorkBook) {
		if (sheetNumber >= tempWorkbook.getNumberOfSheets()) {
			int numSheetsToAdd = sheetNumber - tempWorkbook.getNumberOfSheets() + 1;
			for (int i = 0; i < numSheetsToAdd; i++) {
				tempWorkbook.createSheet();
				cloneWorkBook.createSheet();
			}
			return true;
		}
		return false;

	}

	private int writingDataToExcel(Workbook tempWorkbook, Sheet sheet, int rowNum, Sheet sheetSample,
			FormulaEvaluator evaluator, JsonElement jsonElement) {
		Row row;
		JsonObject obj = jsonElement.getAsJsonObject();
		row = sheet.createRow(rowNum++);
		int cellNum = 0;
		for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
			Cell cell = row.createCell(cellNum++);
			if (entry.getValue() != null && !(entry.getValue() instanceof JsonNull)) {

				// Use header row cell style if data is not overriding the header
				Row sampleRow = sheetSample.getRow(row.getRowNum());
				if (sampleRow != null) {
					Cell cellFormat = sampleRow.getCell(cell.getColumnIndex());
					if (cellFormat != null) {
						CellStyle cellStyle = cellFormat.getCellStyle();
						CellStyle newStyle = tempWorkbook.createCellStyle();
						newStyle.cloneStyleFrom(cellStyle);
						cell.setCellStyle(newStyle);

					}
				}

				Object value = null;
				if (entry.getValue().isJsonPrimitive()) {
					JsonPrimitive primitive = entry.getValue().getAsJsonPrimitive();
					if (primitive.isNumber()) {
						value = primitive.getAsNumber().doubleValue();
					} else if (primitive.isBoolean()) {
						value = primitive.getAsBoolean();
					} else if (primitive.isString()) {
						String stringValue = primitive.getAsString();
						// Check if the string value is a date in the format "dd-MM-yyyy"
						try {
							SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
							Date dateValue = dateFormat.parse(stringValue);
							value = dateValue;
							System.out.println("dateValue : " + dateValue);
						} catch (ParseException e) {
							// Not a valid date format, treat as a regular string value
							value = stringValue;
						}
					} else if (entry.getValue().isJsonArray() || entry.getValue().isJsonObject()) {
						value = entry.getValue().toString();
					}

					if (cell.getCellType() == CellType.FORMULA) {
						if (value instanceof String && ((String) value).matches("\\$[A-Z]+\\$[0-9]+")) {
							// Evaluate dollar formula and set the cell value to the result
							cell.setCellValue(evaluator.evaluate(cell).getNumberValue());
						} else if (value instanceof Number) {
							// Parse value as a numeric value
							double numericValue = ((Number) value).doubleValue();
							cell.setCellValue(numericValue);
						}
					} else {
						// Parse value as appropriate data type
						if (value instanceof Number) {
							// Numeric value
							double numericValue = ((Number) value).doubleValue();
							cell.setCellValue(numericValue);
							boolean isValid = isCellValueValid(cell);
							if (isValid) {
								cell.setCellValue(numericValue);
							} else {
								cell.setCellValue("");
							}
						} else if (value instanceof Boolean) {
							// Boolean value
							boolean booleanValue = (Boolean) value;
							cell.setCellValue(booleanValue);
						} else if (value instanceof String) {
							// String value
							cell.setCellValue((String) value);
						} else if (value instanceof Date) {
							// Write date value to cell
							Date dateValue = (Date) value;
							cell.setCellValue(dateValue);
						} else {
							// Unsupported data type
							cell.setCellValue("");
						}
					}
				}
				// sheet.removeMergedRegion(row.getRowNum());
			}
		}
		return rowNum;
	}

	private int writingHeadersInExcel(Workbook tempWorkbook, Sheet sheet, JsonArray json, int rowNum, int colNumber,
			Sheet sheetSample, boolean sheetFlag) {
		System.out.println("Inside writing headers in excel ");
		Row row;
		row = sheet.createRow(rowNum++);
		System.out.println("Json Object : " + json.get(0).getAsJsonObject());
		for (Map.Entry<String, JsonElement> entry : json.get(0).getAsJsonObject().entrySet()) {

			Cell cell = row.createCell(colNumber++);
			if (!sheetFlag) {
				Row sampleRow = sheetSample.getRow(row.getRowNum());
				if (sampleRow != null) {
					Cell cellFormat = sampleRow.getCell(cell.getColumnIndex());
					if (cellFormat != null) {
						CellStyle cellStyle = cellFormat.getCellStyle();
						CellStyle newStyle = tempWorkbook.createCellStyle();
						newStyle.cloneStyleFrom(cellStyle);
						cell.setCellValue(entry.getKey());
						cell.setCellStyle(newStyle);
					} else {
						cell.setCellValue(entry.getKey());
					}
				} else {
					cell.setCellValue(entry.getKey());
				}
			} else {
				cell.setCellValue(entry.getKey());
			}
		}

		// sheet.removeMergedRegion(row.getRowNum());
		return rowNum;
	}

	private static boolean isCellValueValid(Cell cell) {
		Sheet sheet = cell.getSheet();
		int cellRowIndex = cell.getRowIndex();
		int cellColumnIndex = cell.getColumnIndex();

		for (DataValidation dataValidation : sheet.getDataValidations()) {
			CellRangeAddressList addressList = dataValidation.getRegions();
			for (CellRangeAddress address : addressList.getCellRangeAddresses()) {
				if (address.isInRange(cellRowIndex, cellColumnIndex)) {
					DataValidationConstraint validationConstraint = dataValidation.getValidationConstraint();
					int validationType = validationConstraint.getValidationType();

					switch (validationType) {
					case ValidationType.LIST:
						String[] listValues = validationConstraint.getExplicitListValues();
						if (listValues != null) {
							double cellValue = cell.getNumericCellValue();
							for (String value : listValues) {
								if (Double.valueOf(value).equals(cellValue)) {
									return true;
								}
							}
							return false;
						}
					default:
						return true;
					}
				}
			}
		}

		return true;
	}

	@Input(required = Required.ALWAYS, defaultValue = "output")
	@Name("OutputExcelDocumentName")
	public void setOutputExcelDocumentName(String outputExcelDocumentName) {
		this.outputExcelDocumentName = outputExcelDocumentName;
	}

	@Input(required = Required.OPTIONAL, defaultValue = "Sheet")
	@Name("SheetName")
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	@Input(required = Required.OPTIONAL, defaultValue = "1")
	@Name("SheetNumber")
	public void setSheetNumber(Integer sheetNumber) {
		this.sheetNumber = sheetNumber - 1;
	}

	@Input(required = Required.OPTIONAL, defaultValue = "2")
	@Name("RowNumber")
	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber - 1;
	}

	@Input(required = Required.OPTIONAL, defaultValue = "true")
	@Name("HeaderFlag")
	public void setHeaderFlag(Boolean headerFlag) {
		this.headerFlag = headerFlag;
	}

	@Input(required = Required.ALWAYS)
	@Name("SaveInFolder")
	@FolderDataType
	public void setSaveInFolder(Long val) {
		this.saveInFolder = val;
	}

	@Input(required = Required.ALWAYS)
	@Name("Json")
	public void setJson(String jsonObject) {
		this.jsonObject = jsonObject;
	}

	@Input(required = Required.OPTIONAL)
	@Name("InputExcelTemplate")
	@DocumentDataType
	public void setInputExcelTemplate(Long excelTemplate) {
		this.excelTemplate = excelTemplate;
	}

	@Name("NewExcelDocumentCreated")
	@DocumentDataType
	public Long getNewExcelDocumentCreated() {
		return newExcelDocumentCreated;
	}

	@Name("errorOccured")
	public boolean getErrorOccured() {
		return errorOccured;
	}

	@Name("errorMessage")
	public String getErrorMessage() {
		return errorMessage;
	}

}
